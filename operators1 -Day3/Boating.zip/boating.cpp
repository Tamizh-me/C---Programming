#include<iostream>
using namespace std;
int main(){
    int a,b,c;
    cin>>a>>b>>c;
    int x=75;
    int y=50;
    int wt=(b*x)+(c*y);
    if(wt<=a){
        cout<<"Boat is Stable";
    }else{
        cout<<"Boat will drown";
    }
}