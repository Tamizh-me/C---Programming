#include<iostream>
using namespace std;
int main(){
    int a;
    int b;
    cin>>a>>b;
    if(a>b){
        cout<<a<<" is greater";
    }
    else{
        cout<<b<<" is greater";
    }
}