#include<iostream>
using namespace std;
int main(){
    int a;
    cin>>a;
    if(a==(a*a)%10){
        cout<<"Automorphic number";
    }else{
        cout<<"Not Automorphic number";
    }
}