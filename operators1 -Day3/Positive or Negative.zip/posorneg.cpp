#include<iostream>
using namespace std;
int main(){
    int a;
    cin>>a;
    if(a>0){
        cout<<"Positive";
    
    }else if(a<0){
        cout<<"Negative";
    }else if(a==0){
        cout<<"Equal to 0";
    }
}